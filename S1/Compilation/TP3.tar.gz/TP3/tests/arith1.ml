print 4 + 6;
newline;
exit;
