var x;

print x;
exit;
