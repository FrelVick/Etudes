begin
  var x;
  x := 2;
  print x;
  var x;
  print x;
  begin
    x := 6;
    var x;
    x := 4;
    print x;
  end
  print x;
end
newline;
exit;
