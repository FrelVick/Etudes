var x;
var y;
x := 1;
y := 2;
print x;
print y;
exit;
