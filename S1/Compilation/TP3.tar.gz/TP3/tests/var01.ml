var x;
x := 1;
print x;
exit;
