var x;
x := 1;
var x;
print x;
exit;
