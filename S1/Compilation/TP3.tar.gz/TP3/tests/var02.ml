var x;
x := 1;  
print x;
x := 2;
print x;
exit;
