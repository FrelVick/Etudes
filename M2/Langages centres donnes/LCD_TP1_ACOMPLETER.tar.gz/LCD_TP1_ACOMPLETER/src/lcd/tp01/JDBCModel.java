package lcd.tp01;

import java.sql.*;
import java.io.*;
import java.util.Map;
import java.util.Vector;
import java.util.Collection;

class JDBCModel implements IModel {

	private Connection connection = null;
	private static final String[] tableNames = { "MOVIE", "PEOPLE", "DIRECTOR", "ROLE" };

	JDBCModel(String username, String password, String base) throws SQLException, ClassNotFoundException {

		/*
		 * À COMPLETER CONNEXION À LA BASE POSTGRESQL SUR LA MACHINE tp-postgres
		 */

	}

	public String[] getTableNames() {
		return tableNames;
	}

	// Ferme explicitement la connexion.
	public void close() throws Exception {
		if (connection != null) {
			/*
			 * À COMPLETER FERMER LA CONNEXION ET INITIALISER À NULL
			 */
		}

	}

	// Appelé lors de la destruction de l'objet par le GC.
	protected void finalize() throws Throwable {
		this.close();
	}

	public void initialize() throws SQLException {
		if (connection != null) {
			/*
			 * À COMPLÉTER - DÉTRUIRE LES TABLES EXISTANTES - CRÉER LES TABLES
			 * AVEC LE SCHEMA DEMANDÉ
			 */
		}

	}

	private void fillMovie(BufferedReader r) throws SQLException, IOException {

		/*
		 * À COMPLÉTER : lire 'r' ligne à ligne et remplir la table MOVIE. On
		 * pourra utiliser String.split() pour séparer selon des ';'.
		 */

	}

	private void fillPeople(BufferedReader r) throws SQLException, IOException {
		/*
		 * À COMPLÉTER : lire 'r' ligne à ligne et remplir la table MOVIE. On
		 * pourra utiliser String.split() pour séparer selon des ';'.
		 */
	}

	private void fillDirector(BufferedReader r) throws SQLException, IOException {
		/*
		 * À COMPLÉTER : lire 'r' ligne à ligne et remplir la table MOVIE. On
		 * pourra utiliser String.split() pour séparer selon des ';'.
		 */

	}

	private void fillRole(BufferedReader r) throws SQLException, IOException {
		/*
		 * À COMPLÉTER : lire 'r' ligne à ligne et remplir la table MOVIE. On
		 * pourra utiliser String.split() pour séparer selon des ';'.
		 */
	}

	public void fillTables(Map<String, File> files) throws Exception {
		if (connection != null) {
			try {
				/*
				 * CADEAU, BIEN LIRE LE CODE MAIS RIEN À COMPLÉTER
				 */
				connection.setAutoCommit(false);
				File f;
				f = files.get("MOVIE");
				if (f == null)
					throw new Exception();
				fillMovie(new BufferedReader(new FileReader(f)));

				f = files.get("PEOPLE");
				if (f == null)
					throw new Exception();
				fillPeople(new BufferedReader(new FileReader(f)));

				f = files.get("DIRECTOR");
				if (f == null)
					throw new Exception();
				fillDirector(new BufferedReader(new FileReader(f)));

				f = files.get("ROLE");
				if (f == null)
					throw new Exception();
				fillRole(new BufferedReader(new FileReader(f)));

				connection.commit();

			} catch (Exception e) {
				connection.rollback();
				close();
				throw (e);
			}

		}
	}

	public Collection<String> query(String pattern) throws Exception {

		if (connection != null) {
			pattern = "'%" + pattern + "%'";
			Vector<String> v = new Vector<String>();

			/*
			 * À COMPLÉTER. ÉCRIRE DES REQUÊTES POUR REMPLIR v
			 * AFIN QU'IL CONTIENNE DES CHAINES DE LA FORME
			   Titre, Année, durée, Real1, …, Realn, Acteur 1 : Role 1, … Acteur m: Role m
			 */

			return v;

		} else
			throw new Exception();

	}
}
