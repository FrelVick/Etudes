package lcd.tp01;

import java.sql.*;
import java.io.*;
import java.util.Map;
import java.util.Vector;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import java.util.Collection;
import java.util.HashMap;

class JDBCModel implements IModel {

	private Connection connection = null;
	private static final String[] tableNames = { "MOVIE", "PEOPLE", "DIRECTOR", "ROLE" };

	JDBCModel(String username, String password, String base) throws SQLException, ClassNotFoundException {

		/*
		 * À COMPLETER CONNEXION À LA BASE POSTGRESQL SUR LA MACHINE tp-postgres
		 */
		Class.forName("org.postgresql.Driver");
		  connection =
		  DriverManager.getConnection("jdbc:postgresql://tp-postgres:5432/" + base,
			username, password);

	}

	public String[] getTableNames() {
		return tableNames;
	}

	// Ferme explicitement la connexion.
	public void close() throws Exception {
		if (connection != null) {
			/*
			 * À COMPLETER FERMER LA CONNEXION ET INITIALISER À NULL
			 */
			connection.close();
			connection = null;
		}

	}

	// Appelé lors de la destruction de l'objet par le GC.
	protected void finalize() throws Throwable {
		this.close();
	}

	public void initialize() throws SQLException {
		if (connection != null) {
			/*
			 * À COMPLÉTER - DÉTRUIRE LES TABLES EXISTANTES - CRÉER LES TABLES
			 * AVEC LE SCHEMA DEMANDÉ
			 */
			Statement s = connection.createStatement();
			s.addBatch("DROP TABLE IF EXISTS ROLE");
			s.addBatch("DROP TABLE IF EXISTS DIRECTOR");
			s.addBatch("DROP TABLE IF EXISTS PEOPLE");
			s.addBatch("DROP TABLE IF EXISTS MOVIE");
			
			s.addBatch("CREATE TABLE PEOPLE (pid INTEGER, firstname VARCHAR(30), lastname VARCHAR(30), PRIMARY KEY(pid))");

			s.addBatch("CREATE TABLE MOVIE (mid INTEGER, title VARCHAR(90) NOT NULL, year INTEGER NOT NULL, runtime INTEGER NOT NULL, rank INTEGER NOT NULL, PRIMARY KEY (mid))");

			s.addBatch("CREATE TABLE ROLE (mid INTEGER, pid INTEGER, name VARCHAR(70), PRIMARY KEY(mid, pid, name), FOREIGN KEY (mid) REFERENCES MOVIE, FOREIGN KEY (pid) REFERENCES PEOPLE)");

			s.addBatch("CREATE TABLE DIRECTOR (mid INTEGER, pid INTEGER, PRIMARY KEY (mid, pid), FOREIGN KEY (mid) REFERENCES MOVIE, FOREIGN KEY (pid) REFERENCES PEOPLE)");
			
			s.executeBatch();
			
		}

	}

	private void fillMovie(BufferedReader r) throws SQLException, IOException {

		/*
		 * À COMPLÉTER : lire 'r' ligne à ligne et remplir la table MOVIE. On
		 * pourra utiliser String.split() pour séparer selon des ';'.
		 */

		String s;
		Statement state = connection.createStatement();
		while ((s=r.readLine())!=null){

			System.out.println(s);
			String[] line = s.split(";");
			line[1] = line[1].replaceAll("'", "''");
			line[1] = "'" + line[1] + "'";
			
			String query = "INSERT INTO MOVIE VALUES (";
			for (int i = 0; i<4; i++) {
				query += line[i] + ", ";
			}
			query += line[4] + ")";
			System.err.println(query);
			state.executeUpdate(query);
		}

	}

	private void fillPeople(BufferedReader r) throws SQLException, IOException {
		/*
		 * À COMPLÉTER : lire 'r' ligne à ligne et remplir la table MOVIE. On
		 * pourra utiliser String.split() pour séparer selon des ';'.
		 */
		
		String s;
		Statement state = connection.createStatement();
		while ((s=r.readLine())!=null){

			System.out.println(s);
			String[] line = s.split(";");
			line[1] = line[1].replaceAll("'", "''");
			line[1] = "'" + line[1] + "'";
			line[2] = line[2].replaceAll("'", "''");
			line[2] = "'" + line[2] + "'";
			
			String query = "INSERT INTO PEOPLE VALUES (";
			for (int i = 0; i<2; i++) {
				query += line[i] + ", ";
			}
			query += line[2] + ")";
			System.err.println(query);
			state.executeUpdate(query);
		}
	}

	private void fillDirector(BufferedReader r) throws SQLException, IOException {
		/*
		 * À COMPLÉTER : lire 'r' ligne à ligne et remplir la table MOVIE. On
		 * pourra utiliser String.split() pour séparer selon des ';'.
		 */
		String s;
		Statement state = connection.createStatement();
		while ((s=r.readLine())!=null){

			System.out.println(s);
			String[] line = s.split(";");
			
			String query = "INSERT INTO DIRECTOR VALUES (";
			for (int i = 0; i<1; i++) {
				query += line[i] + ", ";
			}
			query += line[1] + ")";
			System.err.println(query);
			state.executeUpdate(query);
		}
	}

	private void fillRole(BufferedReader r) throws SQLException, IOException {
		/*
		 * À COMPLÉTER : lire 'r' ligne à ligne et remplir la table MOVIE. On
		 * pourra utiliser String.split() pour séparer selon des ';'.
		 */
		
		String s;
		Statement state = connection.createStatement();
		while ((s=r.readLine())!=null){

			System.out.println(s);
			String[] line = s.split(";");
			line[2] = line[2].replaceAll("'", "''");
			line[2] = "'" + line[2] + "'";
			
			String query = "INSERT INTO ROLE VALUES (";
			for (int i = 0; i<2; i++) {
				query += line[i] + ", ";
			}
			query += line[2] + ")";
			System.err.println(query);
			state.executeUpdate(query);
		}
	}

	public void fillTables(Map<String, File> files) throws Exception {
		if (connection != null) {
			try {
				/*
				 * CADEAU, BIEN LIRE LE CODE MAIS RIEN À COMPLÉTER
				 */
				connection.setAutoCommit(false);
				File f;
				f = files.get("MOVIE");
				if (f == null)
					throw new Exception();
				fillMovie(new BufferedReader(new FileReader(f)));

				f = files.get("PEOPLE");
				if (f == null)
					throw new Exception();
				fillPeople(new BufferedReader(new FileReader(f)));

				f = files.get("DIRECTOR");
				if (f == null)
					throw new Exception();
				fillDirector(new BufferedReader(new FileReader(f)));

				f = files.get("ROLE");
				if (f == null)
					throw new Exception();
				fillRole(new BufferedReader(new FileReader(f)));

				connection.commit();

			} catch (Exception e) {
				connection.rollback();
				close();
				throw (e);
			}

		}
	}

	public Collection<String> query(String pattern) throws Exception {

		if (connection != null) {
			pattern = "'%" + pattern + "%'";
			Vector<String> v = new Vector<String>();

			/*
			 * À COMPLÉTER. ÉCRIRE DES REQUÊTES POUR REMPLIR v
			 * AFIN QU'IL CONTIENNE DES CHAINES DE LA FORME
			   Titre, Année, durée, Real1, …, Realn, Acteur 1 : Role 1, … Acteur m: Role m
			 */
			
			return v;

		} else
			throw new Exception();

	}
}
